<?php
namespace App\Controller;
use App\Entity\Article;
use App\Form\ArticleType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class IndexController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;

    }
    
    #[Route('/', name: 'articles', methods: ['GET'])]
    public function home(EntityManagerInterface $entityManager)
    {
       // $articles = ['Article 1', 'Article 2', 'Article 3'];
       // return $this->render('index.html.twig', ['articles' => $articles]);
      //récupérer tous les articles de la table article de la BD
 // et les mettre dans le tableau $articles
    $articleRepository = $entityManager->getRepository(Article::class);
    $articles = $articleRepository->findAll();

    return $this->render('articles/index.html.twig', ['articles' => $articles]);
    }

    #[Route('/article/save', name: 'save', methods: ['GET'])]
    public function save(EntityManagerInterface $entityManager)
    {
        $entityManager = $entityManager; 
        $article = new Article();
        $article->setNom('Article 1');
        $article->setPrix(1000);
        
        $entityManager->persist($article);
        $entityManager->flush();
        
        return new Response('Article enregistré avec id ' . $article->getId());
    }
     #[Route('/article/new', name: 'new_article', methods: ['GET','POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager)
    {
       $article = new Article();

        $form = $this->createFormBuilder($article)
            ->add('nom', TextType::class)
            ->add('prix', TextType::class)
            ->add('save', SubmitType::class, ['label' => 'Créer'])
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $article = $form->getData();

            $entityManager->persist($article);
            $entityManager->flush();

            return $this->redirectToRoute('article_list');
        }

        return $this->render('articles/new.html.twig', ['form' => $form->createView()]);
    }

    #[Route('/article/{id}', name: 'show', requirements: ['id' => '\d+'])] // Validate ID format
public function show(int $id, EntityManagerInterface $entityManager) // Inject EntityManager
{
    $article = $entityManager->getRepository(Article::class)->find($id);

    if (!$article) {
        throw $this->createNotFoundException('Aucun article trouvé avec cet ID'); // Handle missing article
    }

    return $this->render('articles/show.html.twig', ['article' => $article]);
}

    /**
 * @Route("/article/edit/{id}", name="edit_article")
 * Method({"GET", "POST"})
 */
#[Route('/article/edit/{id}', name: 'edit_article')]
public function edit(Request $request, $id)
{
    $article = $this->entityManager->getRepository(Article::class)->find($id);

    if (!$article) {
        throw $this->createNotFoundException('Article non trouvé pour l\'id '.$id);
    }
    $form = $this->createForm(ArticleType::class, $article);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $this->entityManager->flush();
        return $this->redirectToRoute('article_list');
    }

    return $this->render('articles/edit.html.twig', ['form' => $form->createView()]);
}
 

 
#[Route('/article/delete/{id}', name: 'delete_article', methods: ['GET','DELETE'], requirements: ['id' => '\d+'])]
public function delete(Request $request, int $id, EntityManagerInterface $entityManager)
{
    $article = $entityManager->getRepository(Article::class)->find($id);

    if (!$article) {
        throw $this->createNotFoundException('Aucun article trouvé avec cet ID'); // Handle missing article
    }

    $entityManager->remove($article);
    $entityManager->flush();

    // Assuming a JavaScript-based deletion request
    return $this->json(['success' => true]); // Return appropriate response based on request type
        return $this->render('articles/show.html.twig', ['form' => $form->createView()]);

  }
}